<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

  * {
  box-sizing: border-box;
}
  

 .container {
  position:absolute;
  max-width: 1300px;
  margin: 0 auto;

    
  
}

.container img {vertical-align: center;}

.container .content {
  position:fixed;
  bottom: 0;
  background: rgb(0, 0, 0); /* Fallback color */
  background: rgba(0, 0, 0, 0); /* Black background with 0.5 opacity */
  color:white;
  width: 102%;
  padding: 200px;
  margin-left: 30px
font-size:50px;
 }
  

body {font-family: georgia;color:white;}
* {box-sizing: border-box;} 
      
  
 
 
 

.title {
  color: white;
}

body {
  overflow-y: hidden; /* Hide vertical scrollbar */
  overflow-x: hidden; /* Hide horizontal scrollbar */
} 
 
}
</style>

<style type='text/css'>
  body {
    background-color: black
  }
  
  h1 {
    color:pink;
  }

   h2 {
    color:teal;
  }
   h3{
    color:white;
  }
  
   
</style>
</head>
<body>

  <div class="container">
  <img src="Business-Background,-Photos,-and-Wallpaper-for-Free-Download.jpg" height="100%", alt="Notebook" style="width:300%;">
  <div class="content">
 
  
<div class="bg-img"> 
<body bgcolor="Black">

<h1><CENTER>E-HEALTHCARE ONLINE CONSULTATION AND MEDICAL SUBSCRIPTION</CENTER></h1>

<h2><CENTER>ABOUT US</h2></CENTER>
 
<h3><b><center>VISION AND MISSION</h3></b></center>
<h3>Welcome to
eHealthSystem is an organisation that assimilates resources which helps to create a health ecosystem that brings connectivity for unified health management.

The company has developed a system, called eHealthcareSystem (eHS) that digitizes healthcare information for all healthcare consumers  
E-healthcare system Benefits To User/Citizen.
The E consultation system is an end user support and online consultation project. Here we propose a system that connects patients to available doctors for online consultation and also allows subscriptions to patient. Our proposed system aims to build an environment where various patients needing doctor help at their home can consult doctors, send their images(for skin diseases/beauty related issues), chat with doctors, tell them their issues and discuss remedies.

The proposed application aims to create a friendly working environment for any health care centres.

 
 Our Vision
Wellness For Body, Mind & Spirit

Our Mission
connect doctors and patients.
Actions
Technology Innovative Approach Experience</h3>
</body>
</html>

  
