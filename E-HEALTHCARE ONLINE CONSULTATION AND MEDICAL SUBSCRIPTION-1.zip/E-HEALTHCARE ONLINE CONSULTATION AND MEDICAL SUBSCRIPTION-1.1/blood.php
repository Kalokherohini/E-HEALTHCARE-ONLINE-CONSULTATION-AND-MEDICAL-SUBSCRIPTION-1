 <!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  * {
  box-sizing: border-box;
}
 

.container {
  position:center;
  max-width: 1500px;
  margin: 0 auto;
}

.container img {vertical-align: center;}

.container .content {
  position:fixed;
  bottom: 0;
  background: rgb(0, 0, 0); /* Fallback color */
  background: rgba(0, 0, 0, 0.6); /* Black background with 0.5 opacity */
  color: #f1f1f1;
  width: 100%;
  padding: 180px;
  font-size: 30;
  font-size: 17px;
}

 
</style>
</head>
<body>
 
  <div class="container">
  <img src="bp.jfif" height="100%", alt="Notebook" style="width:100%;">
  <div class="content">
 
</head>
  <body>

 
<div class="bg-img">
<body bgcolor="Black">

   
   

 

  <div class="imgcontainer">
    
  </div>
 
<br><h1><center>for controlling blood pressure tips</h1></center>
  
 <b>1. Amla</b>
Amla for Blood Pressure- Activ Living
Amla or Indian Gooseberry is an effective ayurvedic medicine for blood pressure. It has Vitamin C which helps reduce blood cholesterol levels and widens blood vessels. If you have amla juice every morning on an empty stomach it can control hypertension and other ailments too.<br><br>

<b>2. Gotu Kola</b>
Gotu Kola- Activ Living
Gotu Kola also known as Indian Pennywort is commonly used in Traditional Chinese and Ayurvedic medicine. This bitter herb, taken in small quantities, can prove beneficial for blood circulation and control blood pressure..<br><br>

<b>3. Ashwagandha</b>
Ashwagandha- Activ Living
Ashwagandha or Indian Ginseng is a natural herb that you can add to your evening tea in small quantities. It has been proven to lower blood pressure along with acupressure points for blood pressure. Studies also suggest that it can reduce blood sugar levels in people with diabetes..<br><br>

<b>4. Garlic</b>
Garlic- Activ Living
Garlic helps lower your blood pressure since it is a natural blood thinner and it reduces cholesterol levels. You can try consuming one clove of garlic in the morning as it will have multiple health benefits in the long run..<br><br>

<b>5. Honey</b>
Honey- Activ Living
If you consume two teaspoons of honey with warm water every morning, it can work wonders for your health. Honey is a great remedy to relax the walls of blood vessels and control blood pressure levels.

You don’t need to adopt all of these best ayurvedic medicines for blood pressure immediately. Find the one that soothes your ailment and stick with that. Browse more such articles on fitness and health that might help you improve your lifestyle in a healthy and safe way.

Health insurance for hypertension includes chronic management plans to control lifestyle diseases like Asthma, Blood Pressure, Cholesterol and Diabetes.
</B></P></CENTER>
  <div class="container">
 

     


   
</form>

</body>
</html>
