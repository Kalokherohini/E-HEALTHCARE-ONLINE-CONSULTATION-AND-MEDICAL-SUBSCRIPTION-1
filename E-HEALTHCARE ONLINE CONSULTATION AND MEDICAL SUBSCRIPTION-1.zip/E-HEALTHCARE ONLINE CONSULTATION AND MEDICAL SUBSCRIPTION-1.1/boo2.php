  
   <!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  * {
  box-sizing: border-box;
}
  

.container {
  position:center;
  max-width: 800px;
  margin: 0 auto;
}

.container img {vertical-align: center;}

.container .content {
  position:absolute;
  bottom: 0;
  background: rgb(0, 0, 0); /* Fallback color */
  background: rgba(0, 0, 0, 0.5); /* Black background with 0.5 opacity */
  color: #f1f1f1;
  width: 50%;
  padding: 10px;
  font-size: 19.5px;
}

body {
  font-family: 'georgia';
}


input[type=text], input[type=password] {
  width: 100%;
  padding: 10px 10px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color:  DodgerBlue;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: DodgerBlue;
}

 

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: center;
  }
  .cancelbtn {
     width: 100%;
  }
}

body {
  overflow-y: hidden; /* Hide vertical scrollbar */
  overflow-x: hidden; /* Hide horizontal scrollbar */
}
</style>
</head>
<body>


 
  <div class="container">
  <img src="r2.JPEG" height="100%", alt="Notebook" style="width:100%;">
  <div class="content">
 
 

  
<div class="bg-img"> 
<body bgcolor="Black">

   <form action="http://localhost/ehealthcare/simplechat/simplechat/index.php">


<h1>E-HEALTHCARE ONLINE CONSULTATION AND MEDICAL SUBSCRIPTION</h1><BR><BR>
<marquee>WELCOME TO E-HEALTHCARE ONLINE CONSULTATION AND MEDICAL SUBSCRIPTION </marquee>
<img src="wppppp.JPEG" height="100%", alt="Notebook" style="width:100%;"> 
<P>WELCOME TO E-HEALTHBCARE ONLINE CONSULTATION AND MEDICAL SUBSCRIPTION...
Here we propose a system that connects patients to available doctors for online consultation.
Our proposed system aims to build an environment where various patients needing doctor help at their home.
Doctors can handle emergency situation by providing primary help, till the patient can be taken to the hospital. 
at emergency situation go to contact us for quick primary consultation or if have some query about the system send your feedback in feedback section..</P>
<button type="submit"> NEXT<<
 
</button>
    <label>
 
</div>
</head>
</body>
</html>