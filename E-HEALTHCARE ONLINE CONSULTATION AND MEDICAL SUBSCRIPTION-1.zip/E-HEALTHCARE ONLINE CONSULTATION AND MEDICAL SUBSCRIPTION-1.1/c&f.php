 <!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  * {
  box-sizing: border-box;
}
 

.container {
  position:center;
  max-width: 1500px;
  margin: 0 auto;
}

.container img {vertical-align: center;}

.container .content {
  position:fixed;
  bottom: 0;
  background: rgb(0, 0, 0); /* Fallback color */
  background: rgba(0, 0, 0, 0.6); /* Black background with 0.5 opacity */
  color: #f1f1f1;
  width: 100%;
  padding: 180px;
  font-size: 30;
  font-size: 17px;
}

 
</style>
</head>
<body>
 
  <div class="container">
  <img src="c&f.jpg" height="100%", alt="Notebook" style="width:100%;">
  <div class="content">
 
</head>
  <body>

 
<div class="bg-img">
<body bgcolor="Black">

   
   

 

  <div class="imgcontainer">
    
  </div>
 
<br><h1><center>cough and fever tips</h1></center>
  
Home Remedies for Fever and cough Symptoms

<b>Rest</b>
Activity can raise your body temperature. You need to rest in order to recover and reduce a fever. For an adult whose fever is 102°F (38.9°C) or lower, the recommendation is simply to rest and drink lots of fluids. Medication isn’t always necessary. Getting enough sleep can also help to support the integrity of your immune system, so your body can fight fever-causing viruses like a cold or flu.8

Call a doctor if your fever is accompanied by a severe headache, stiff neck, shortness of breath or other unusual signs or symptoms.<br><br>


<b>Hydration</b>
Having a fever can cause fluid loss and dehydration. It’s important to drink plenty of fluids when you have a fever. Adequate fluid intake is often advised as part of a treatment plan for fever-inducing infections like the flu.7<br><br>

<b>A cool environment</b>
Keeping the room temperature cool and sleeping with only a sheet or light blanket can help keep you cooler. If your child has a fever, adjust the temperature in the house or bedroom to help keep them cool.9<br><br>

<b>Light clothing</b>
When you want to break a fever, it’s also a good idea to dress in light clothing, as lighter clothing can have a cooling effect.10 It’s been reported that very warm clothing may increase a child’s body temperature even in the case that they are not ill.11<br><br>

<b>Over-the-Counter Medicines that Reduce Fever<b>

A fever is not a pleasant symptom to experience. The chills, shivering, and headaches can become uncomfortable enough that you want relief. Keep over-the-counter medicines on hand with active ingredients that can reduce fever. Acetaminophen, for example is an over-the-counter medication that is approved for use against fever, even in children.10<br><br>

Acetaminophen is a commonly used drug for reducing fever that also relieves minor aches and pains.14 But you may find that when you have a cold or flu, there are more symptoms that you need relief from, like coughing or nasal congestion.<br><br>

Many over-the-counter cold and flu medicines treat multiple symptoms, including fever. Make sure to identify what other symptoms you may be experiencing along with fever, if any, so you can get the relief you need. Keep reading for Vicks products that can help reduce fever, along with other common cold and flu symptoms.

 
</B></P></CENTER>
  <div class="container">
 

     


   
</form>

</body>
</html>
