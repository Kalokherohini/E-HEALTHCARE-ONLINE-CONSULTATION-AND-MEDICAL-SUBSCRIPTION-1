<!DOCTYPE html>

<html>

<head>

<meta name="viewport" content="width=device-width, initial-scale=1">

<style>

body {
 
 font-family: 'Lato', sans-serif;

}


.container {
 
 position:absolute;
  max-width: 1300px;
  margin: 0 auto;

}


.container img {
vertical-align: center;
}


.container .content {

  position:fixed;
  bottom: 0;
  background: rgb(0, 0, 0); /* Fallback color */
  
background: rgba(0, 0, 0, 0); /* Black background with 0.5 opacity */
 
 color:WHITE;
  width: 102%;
  padding: 80px;
  margin-left: 30px


}



body {

  font-family: 'georgia';

}


 
 body {

  overflow-y: hidden; /* Hide vertical scrollbar */
  overflow-x: hidden; /* Hide horizontal scrollbar */

}

button {
  background-color:  DodgerBlue;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 88%;
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: DodgerBlue;
}

</style>

<style type='text/css'>
  
body {

    background-color: black
 
 }
  

  h1 {
 
   color:pink;

}


 p {
    
color:WHITE;

}

</style>

</head>

<body>

<div class="container">
 
  
  
<div class="content">
 
  

  
<body bgcolor="Black">

  
<form action="kaj.php" method="post">


<h1>E-HEALTHCARE ONLINE CONSULTATION AND MEDICAL SUBSCRIPTION</h1>


<MARQUEE><B>START SESSION CHAT WITH DOCTORS HERE</B></MARQUEE>

 


<script>

function openNav() {
  
document.getElementById("myNav").style.height = "100%";

}


function closeNav() 
{

  document.getElementById("myNav").style.height = "0%";

}

</script>

<p>
  <img src="doctor-online.png" height="350"width="1400"></p>


  <P><b>START CONSULTATION THROUGH CHATTING AND VEDIO CALL AND GET PRESCRIPTION IN PRINTATBLE FORMAT</P></b>
   
 <button type="submit">   
   START CONSULTATION</a></button>
    
</html>