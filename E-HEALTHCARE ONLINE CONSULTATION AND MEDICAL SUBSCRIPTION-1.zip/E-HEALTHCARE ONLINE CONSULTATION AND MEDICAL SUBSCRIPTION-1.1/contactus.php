<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

  * {
  box-sizing: border-box;
}
  

 .container {
  position:absolute;
  max-width: 1200px;
  margin: 0 auto;

    
  
}

.container img {vertical-align: center;}

.container .content {
  position:fixed;
  bottom: 0;
  background: rgb(0, 0, 0); /* Fallback color */
  background: rgba(0, 0, 0, 0.5); /* Black background with 0.5 opacity */
  color:white;
  width: 102%;
  padding: 150px;
  margin-left: 30px
font-size:60px;  
 }
  

body {font-family: georgia;color:white;}
* {box-sizing: border-box;} 
      
  
body {
  overflow-y: hidden; /* Hide vertical scrollbar */
  overflow-x: hidden; /* Hide horizontal scrollbar */
} 
 
 

.title {
  color: white;
}

 
 
}
</style>

<style type='text/css'>
  body {
    background-color: black;
  }
  
  h1 {
    color:lightgreen;
  }

   h2 {
    color:white;
  }
   h3{
    color:white;
  }
  
   
</style>
</head>
<body>

  <div class="container">
  <img src= "service.jpg" height="100%", alt="Notebook" style="width:300%;">
  <div class="content">
 
  
<div class="bg-img"> 
<body bgcolor="Black">
<h1><CENTER><img src="https://images.vexels.com/media/users/3/128044/isolated/preview/94f0b955807b088de5dc109c019b6fc9-health-care-medical-sign-by-vexels.png" style="width:11%">E-HEALTHCARE ONLINE CONSULTATION AND MEDICAL SUBSCRIPTION</CENTER></h1> 

<h3><CENTER>CONTACT US</CENTER></h3><BR><BR>

  
 
<p><h3><center>IF YOU WANT PRIMARY CONSULTATION IN EMERGENCY SITUATION CALL ON:<BR><BR>
  EMERGENCY NUMBER:
  TEL:020-7868765<BR><BR>

  FOR ANY QUERYIES CALL:
  TEL:020-6574567<BR><BR></b></center></h4>

<p><center>For Any Inquiries:<br>
contact@ehealthcare.gmail.com</center></p>

<p><center>For Ambulance Call On:<br>
 1800 2435 2345 <br>  1800 2233 3344</center></p>


 
</body>
</html>

  
