<!DOCTYPE html>

<html>

<head>

<meta name="viewport" content="width=device-width, initial-scale=1">

<style>

body {
 
 font-family: 'Lato', sans-serif;

}


.container {
 
 position:absolute;
  max-width: 1300px;
  margin: 0 auto;

}


.container img {
vertical-align: center;
}


.container .content {

  position:fixed;
  bottom: 0;
  background: rgb(0, 0, 0); /* Fallback color */
  
background: rgba(0, 0, 0, 0); /* Black background with 0.5 opacity */
 
 color:WHITE;
  width: 102%;
  padding: 50px;
  margin-left: 30px


}



body {

  font-family: 'georgia';

}


.overlay {

  height: 0%;
  width: 100%;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: rgb(0,0,0);

  background-color: rgba(0,0,0, 0.9);
  overflow-y: hidden;
  transition: 0.5s;

}


.overlay-content {
  
position: relative;
  top: 25%;
  width: 100%;
  text-align: center;
 
 margin-top: 30px;

}


.overlay a {

  padding: 8px;
  text-decoration: none;
  font-size: 69px;
color:WHITE;

    display: block;
  transition: 0.3s;

}


.overlay a:hover, 
.overlay a:focus {

  color: #f1f1f1;

}


.overlay .closebtn {

  position: absolute;
 
 top: 20px;
  right: 45px;
  font-size: 60px;

}

@media screen and (max-height: 450px) {
 
 .overlay {
overflow-y: auto;
}

  .overlay a {
font-size: 20px
}
 
 .overlay .closebtn {

  font-size: 40px;
  top: 15px;
  right: 35px;

  }

}


 body {

  overflow-y: hidden; /* Hide vertical scrollbar */
  overflow-x: hidden; /* Hide horizontal scrollbar */

}

button {
  background-color:  DodgerBlue;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 88%;
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: DodgerBlue;
}

</style>

<style type='text/css'>
  
body {

    background-color: black
 
 }
  

  h1 {
 
   color:pink;

}


 p {
    
color:WHITE;

}

</style>

</head>

<body>

<div class="container">
 
  
  
<div class="content">
 
  

  
<body bgcolor="Black">
<form action="PAYMENT.php">
 <audio autoplay loop>
      <source src="http://localhost/ehealthcare/Voice%20006-1.m4a"/>
      <source src="http://localhost/ehealthcare/Voice%20006-1.ogg"/>
    </audio> 
<div id="myNav" class="overlay">
  
<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  
<div class="overlay-content">

    
    </a>
    <br>
    <br>
    <br>
    <br>
     <br>
    <br>
    <br>
    <br>
 <a href="https://api.whatsapp.com/send?phone=+91965984652">Start Consultation On Whatsapp!<img src="https://i.ibb.co/N9P0K9H/239px-Whats-App-svg.png" width="80" height="80"/></a>
  <a href="http://localhost/ehealthcare/simplechat/simplechat/index.php"><b>start consultation at another way!!!</a></b>   
 

 </div>

</div>


<h1>E-HEALTHCARE ONLINE CONSULTATION AND MEDICAL SUBSCRIPTION</h1>


<MARQUEE><B>START SESSION CHAT WITH DOCTORS HERE</B></MARQUEE>

<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;
Join Chat!!</span>


<script>

function openNav() {
  
document.getElementById("myNav").style.height = "100%";

}


function closeNav() 
{

  document.getElementById("myNav").style.height = "0%";

}

</script>

<p>
  <img src="blog-header-1-1170x460.png" height="350"width="1370"></p>


  <P><b>PAY DOCTORS FEES ON AMAZONPAY,PAYTM OR GOOGLEPAY AND BUY MEDICINES AND GET SOME DISCOUNTS ON IT..</P></b>
   
 <button type="submit">   
   PAY DOCTORS FEES AND BUY MEDICIENS</a></button>
    
</html>