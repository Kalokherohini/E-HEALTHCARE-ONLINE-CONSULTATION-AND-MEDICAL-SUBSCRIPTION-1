<!DOCTYPE html>

<html>

<head>

<meta name="viewport" content="width=device-width, initial-scale=1">

<style>

body {
 
 font-family: 'Lato', sans-serif;

}


.container {
 
 position:absolute;
  max-width: 1300px;
  margin: 0 auto;

}


.container img {
vertical-align: center;
}


.container .content {

  position:fixed;
  bottom: 0;
  background: rgb(0, 0, 0); /* Fallback color */
  
background: rgba(0, 0, 0, 0); /* Black background with 0.5 opacity */
 
 color:WHITE;
  width: 102%;
  padding: 25px;
  margin-left: 30px
font-size:20px;

}



body {

  font-family: 'georgia';

}


.overlay {

  height: 0%;
  width: 100%;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: rgb(0,0,0);

  background-color: rgba(0,0,0, 0.9);
  overflow-y: hidden;
  transition: 0.5s;

}


.overlay-content {
  
position: relative;
  top: 25%;
  width: 100%;
  text-align: center;
 
 margin-top: 30px;

}


.overlay a {

  padding: 8px;
  text-decoration: none;
  font-size: 30px;
color:WHITE;

    display: block;
  transition: 0.3s;

}


.overlay a:hover, 
.overlay a:focus {

  color: #f1f1f1;

}


.overlay .closebtn {

  position: absolute;
 
 top: 20px;
  right: 45px;
  font-size: 60px;

}

@media screen and (max-height: 450px) {
 
 .overlay {
overflow-y: auto;
}

  .overlay a {
font-size: 20px
}
 
 .overlay .closebtn {

  font-size: 40px;
  top: 15px;
  right: 35px;

  }

}

.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
  max-width: 1700px;
}

 
/* The dots/bullets/indicators */
.dot {
  height: 20px;
  width: 20px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 2.2s;
  animation-name: fade;
  animation-duration: 2.2s;

}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .text {font-size: 11px}
}
body
{
   overflow-x: hidden; /* Hide horizontal scrollbar */
    overflow-y: hidden; /* Hide horizontal scrollbar */
} 
 
 

</style>

</head>

<body>

<div class="container">
 
  
    <img src="Business-Background,-Photos,-and-Wallpaper-for-Free-Download.JPG" height="100%", alt="Notebook" style="width:300%;">
  <div class="content">
<div class="content">
 
  

  
<body bgcolor="Black">
<form action="file:///C:/Users/Shruti/Desktop/payment.HTML">
  
<div id="myNav" class="overlay">
  
<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  
<div class="overlay-content">

    
    </a>
 <a href="#">SIGN UP  OR SIGN IN HERE❤</a><BR><BR>    
 <a href="login2.php">NEW USER LOGIN🔐 </a><BR><BR>
 <a href="login.php">PATIENT LOGIN🔐</a><BR><BR>
<a href="newd.php">ADMIN LOGIN🔐</a><BR><BR>
  
    
    
 

 </div>

</div>


<h1><img src="https://images.vexels.com/media/users/3/128044/isolated/preview/94f0b955807b088de5dc109c019b6fc9-health-care-medical-sign-by-vexels.png" style="width:10%">E-HEALTHCARE ONLINE CONSULTATION AND MEDICAL SUBSCRIPTION</h1>


<MARQUEE><B>SIGN IN OR SIGN UP HERE TO BE A MEMBER OF THIS SYSTEM.❤</B></MARQUEE>

<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;
LOGIN HERE!! </span>
 

</body>

<script>

function openNav() {
  
document.getElementById("myNav").style.height = "100%";

}


function closeNav() 
{

  document.getElementById("myNav").style.height = "0%";

}

</script>

<p>
  <img src="blog-header-1-1170x460.png" height="370"width="1410"></p>


  <H2><b>SIGN IN OR SIGN UP HERE TO BE A MEMBER OF THIS SYSTEM.❤</H2></b><br>

   
 </body>

</html>