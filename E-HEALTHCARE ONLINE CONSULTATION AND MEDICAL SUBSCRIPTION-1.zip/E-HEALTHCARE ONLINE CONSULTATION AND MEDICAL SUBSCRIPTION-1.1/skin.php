<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  * {
  box-sizing: border-box;
}
 

.container {
  position:center;
  max-width: 1500px;
  margin: 0 auto;
}

.container img {vertical-align: center;}

.container .content {
  position:fixed;
  bottom: 0;
  background: rgb(0, 0, 0); /* Fallback color */
  background: rgba(0, 0, 0, 0.5); /* Black background with 0.5 opacity */
  color: #f1f1f1;
  width: 100%;
  padding: 150px;
  font-size: 30;
  font-size: 17px;
}

 
</style>
</head>
<body>
 
  <div class="container">
  <img src="skin care.jfif" height="100%", alt="Notebook" style="width:100%;">
  <div class="content">
 
</head>
  <body>

 
<div class="bg-img">
<body bgcolor="Black">

   
   

<form action="/action_page.php" method="post">

  <div class="imgcontainer">
    
  </div>
 
<br><h1><center> skin care tips</h1></center>
 
  You may suspect you have dry, oily, or sensitive skin, but do you really know your skin type? Knowing your true skin type can help the next time you’re in the cosmetics aisle. In fact, using the wrong products — or even popularized Internet hacks — for your skin type could worsen acne, dryness, or other skin problems.<br><br>

Read on to learn:<br>

how to build your own skin care routine
how to treat specific skin concerns like acne or scars
which DIY skin hacks aren’t healthy, even if they seem to work
Building a daily skin care routine
No matter what your skin type is, a daily skin care routine can help you maintain overall skin health and improve specific concerns like acne, scarring, and dark spots. A daily skin care routine has four basic steps you can do once in the morning and once before you sleep.<br><br>
1. Cleansing: Choose a cleanser that doesn’t leave your skin tight after washing. Clean your face no more than twice a day, or just once, if you have dry skin and don’t wear makeup. Avoid washing for that squeaky-clean feeling because that means your skin’s natural oils are gone. Cleansers known to work well for all skin types include Cetaphil and Banila Clean It Zero Sherbet Cleanser.<br><br>

2. Serums: A serum with vitamin C or growth factors or peptides would be better in the morning, under sunscreen. At night, retinol or prescription retinoids work best. Makeup Artist’s Choice has an effective vitamin C and E serum and retinol available.<br><br>

3. Moisturizer: Even oily skin needs moisturizer, but use one that is lightweight, gel-based, and non-comedogenic, or doesn’t block your pores, like CeraVe’s facial lotion. Dry skin may benefit from more cream-based moisturizers like MISSHA Super Aqua Cell Renew Snail Cream. Most brands will label their products as gel or cream on their packaging.<br><br>

4. Sunscreen: Apply sunscreen with at least 30 SPF 15 minutes before heading outdoors, as it takes a while for sunscreen to activate. Darker skin tones actually need more sun protection because hyperpigmentation is harder to correct. Try EltaMD’s sunscreen, which offers broad-spectrum UVA/UVB protection and is recommended by the Skin Cancer Foundation.

Choose products that fit your skin type and sensitivity, and remember to read the labels. Some products, such as retinol or prescription retinoids, should only be applied at night.




 
 
</B></P></CENTER>
  <div class="container">
 

     


   
</form>

</body>
</html>
