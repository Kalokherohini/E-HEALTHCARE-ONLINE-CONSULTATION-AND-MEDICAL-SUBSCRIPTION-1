 <!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

  * {
  box-sizing: border-box;
}
  

 .container {
  position:relative;
  max-width: 1600px;
  margin: 0 auto;

    
  
}

.container img {vertical-align: center;}

.container .content {
  position:fixed;
  bottom: 0;
  background: rgb(0, 0, 0); /* Fallback color */
  background: rgba(0, 0, 0, 0); /* Black background with 0.5 opacity */
  color:white;
  width: 80%;
  padding: 120px;
  margin-left: 30px
 }
  
  body {
  overflow-y: hidden; /* Hide vertical scrollbar */
  overflow-x: hidden; /* Hide horizontal scrollbar */
}

body {font-family: georgia;color:white;}
* {box-sizing: border-box;} 
      
  
 
 
 

.title {
  color: white;
}



</style>

<style type='text/css'>
  body {
    background-color: black
  }
  
  h1 {
    color:pink;
  }

   h2 {
    color:white;
  }
   h3{
    color:yellow;
  }
  
   
</style>
</head>
<body>

  <div class="container">
  <img src="Business-Background,-Photos,-and-Wallpaper-for-Free-Download.JPG" height="100%", alt="Notebook" style="width:300%;">
  <div class="content">
 
  
<div class="bg-img"> 
<body bgcolor="Black">

<h1><CENTER>E-HEALTHCARE ONLINE CONSULTATION AND MEDICAL SUBSCRIPTION</CENTER></h1><BR><BR>
<h3><b><center>TERMS AND CONDITIONS</h3></b></center>
<p> <B> 
Communicating with you
Supplying such information to our partners, associates and contractors for their processing and assessment
Making the sites or services easier to use by eliminating the need for you to repeatedly enter the same information
Providing eHealthSystem Health Care Services;
Dealing with requests, enquiries or complaints and other customer care related activities; and all other general administrative and business purposes;
Carrying out market and product analysis and marketing our companies’ products and services and communicate updates, offers and promotion.
Carrying out activities connected with running of our business such as personnel training, quality control, network monitoring, testing and maintenance of computer and other systems and in connection with the transfer of any part of our business in respect of which you are a customer or a potential customer;
Ensuring the technical functioning of our network
Developing new services
As described in the respective terms of service of each of our services and in the www.ehealthsystem.in Customer Master Agreement
 <BR><BR><BR>

Choices For Personal Information
When you sign up for a particular service that requires registration, we ask you to provide personal information and we will ask for your consent prior to use thereof. Most browsers are initially set up to accept cookies, but you can reset your browser to refuse all cookies or to indicate when a cookie is being sent. However, some of our features and services may not function properly if your cookies are disabled. You can decline to submit personal information to any of our services, in which case we may not be able to provide those services to you.
</p></B><BR>
</body>
</html>

  
