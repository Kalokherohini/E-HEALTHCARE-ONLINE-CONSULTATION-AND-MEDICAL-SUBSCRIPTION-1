  <!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  * {
  box-sizing: border-box;
}
  

.container {
  position:relative;
  max-width: 800px;
  margin: 0 auto;
}

.container img {vertical-align: center;}

.container .content {
  position:absolute;
  bottom: 0;
  background: rgb(0, 0, 0); /* Fallback color */
  background: rgba(0, 0, 0, 0.2); /* Black background with 0.5 opacity */
  color: #f1f1f1;
  width: 50%;
  padding: 100px;
}

 
.container {
  padding: 10px;
}

span.psw {
  float: center;
  padding-top: 10px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: center;
  }
  .cancelbtn {
     width: 100%;
  }
}
body {
  overflow-y: hidden; /* Hide vertical scrollbar */
  overflow-x: hidden; /* Hide horizontal scrollbar */
}
</style>
</head>
<body>
 
  <div class="container">
  <center><img src="https://gracegateways.com/wp-content/uploads/2017/12/thank-pilgrimage-pay-505.png" height="100%", alt="Notebook" style="width:100%;"></center>
  <div class="content">
</head>
  <body>
 
  
<div class="bg-img"> 
<body bgcolor="Black">

   
  
    
      
</form>
 
</body>
</html>
